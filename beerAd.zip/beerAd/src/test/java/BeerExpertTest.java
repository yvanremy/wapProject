import model.BeerExpert;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class BeerExpertTest {
    List listB = new ArrayList();
    List listA = new ArrayList();

    @Test
    public void compare_Lists() {
        listA.add("Jack Amber");
        listA.add("Red Moose");
        BeerExpert bx = new BeerExpert();
        listB = bx.getBrands("amber");

        Assert.assertArrayEquals(listA.toArray(),listB.toArray());
        // ...
    }
}

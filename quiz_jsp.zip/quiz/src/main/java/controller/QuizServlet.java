package controller;

import model.Quiz;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/quiz")
public class QuizServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Quiz sessQuiz = (Quiz) request.getSession().getAttribute("sessQuiz");

        String error = (String)request.getSession().getAttribute("error");


        String answer = request.getParameter("txtAnswer");

        if ((answer != null) && sessQuiz.isCorrect(answer)) {
            sessQuiz.scoreAnswer();
            error = "false";
        } else {
            error = "true";
        }

        System.out.println("Errrorr Serv " + error);

        request.getSession().setAttribute("error", error);

        if (sessQuiz.getScore() == sessQuiz.getNumQuestions()) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("quizend.jsp");
            dispatcher.forward(request, response);
        } else {
            RequestDispatcher dispatcher = request.getRequestDispatcher("quiz.jsp");
            dispatcher.forward(request, response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getSession() == null) {
            request.getSession();
        }
        String error = "false";

        Quiz sessQuiz = new Quiz();

        request.getSession().setAttribute("sessQuiz", sessQuiz);
        request.getSession().setAttribute("error", error);

        RequestDispatcher dispatcher = request.getRequestDispatcher("quiz.jsp");
        dispatcher.forward(request, response);

    }
}
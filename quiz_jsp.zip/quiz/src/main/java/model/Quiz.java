package model;

import java.util.ArrayList;
import java.util.*;

public class Quiz {
    private boolean correct = false;
    private int score = 0;
    private List<Question> questions;


    public Quiz(){
        Question qn1 =new Question("[3, 1, 4, 1, 5, ? ]","9", "PI");
        Question qn2 =new Question("[1, 1, 2, 3, 5, ? ]","8", "Fibonacci");
        Question qn3 =new Question("[1, 4, 9, 16, 25, ? ]","36", "Squares");
        Question qn4 =new Question("[2, 3, 5, 7, 11, ? ]","13" ,"Prime");
        Question qn5 =new Question("[1, 2, 4, 8, 16, ? ]","32" ,  "N * 2");
        questions = new ArrayList(){
            {
                add(qn1);
                add(qn2);
                add(qn3);
                add(qn4);
                add(qn5);
            }
        };

    }


    public int getScore(){

        return score;

    }

    public List<Question> getQuestions(){

        return questions;

    }

    public String getCurrentQuestion(){
        Question currentQn = getCurrentQuestionObj();

        return currentQn.getQuestion();
    }

    public boolean isCorrect(String ans){
        Question currentQn = getCurrentQuestionObj();
        if(ans.equals(currentQn.getAnswer())){
            correct = true;
        }
       return correct;
    }

    public void scoreAnswer(){
        score++;
        correct = false;

    }

    public int getNumQuestions(){
        return questions.size();
    }
    public int getCurrentQuestionIndex(){
        return score;
    }
    public Question getCurrentQuestionObj(){
        return questions.get(score);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trial;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hagenimanayvanremy
 */
public class TrialServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            int  number1 = Integer.parseInt( request.getParameter("number1"));
            int  number2 = Integer.parseInt( request.getParameter("number2"));
            int  number3 = Integer.parseInt( request.getParameter("number3"));
            int  number4 = Integer.parseInt( request.getParameter("number4"));
            
            int sum = number1 + number2;
            int product = number3 * number4;
          //  response.sendRedirect("http://www.google.com");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet TrialServlet</title>");
            out.println("</head>");
            out.println("<body>");
            
             out.println("<div>\n" +
"            <form action=\"TrialServlet\" method=\"POST\">\n" +
"                <input value=\""+number1+"\" type=\"number\" name=\"number1\">\n" +
"                +\n" +
"                <input value=\""+number2+"\" name=\"number2\" type=\"number\">\n" +
"                =\n" +
"                <input name=\"sum\" value=\""+sum+"\" type=\"number\"> <br><br>\n" +
"               <input value=\""+number3+"\" type=\"number\" name=\"number3\">\n" +
"                *\n" +
"                <input value=\""+number4+"\" name=\"number4\" type=\"number\">\n" +
"                =\n" +
"                <input value=\""+product+"\" name=\"product\" type=\"number\"> <br>\n" +
"                <input type=\"submit\" value=\"Submit\">\n" +
"            </form>\n" +
"            \n" +
"        </div>");
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   //here we have seen the difference between web server and web container, how they works and web.xml configuration
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
